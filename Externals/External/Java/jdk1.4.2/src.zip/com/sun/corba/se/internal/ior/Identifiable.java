/*
 * @(#)Identifiable.java	1.8 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

//Source file: J:/ws/serveractivation/src/share/classes/com.sun.corba.se.internal.ior/Identifiable.java

package com.sun.corba.se.internal.ior;


/**
 * @author 
 */
public interface Identifiable 
{
    
    /**
     * @return int
     * @exception 
     * @author 
     * @roseuid 3911D835039E
     */
    public int getId();
}
